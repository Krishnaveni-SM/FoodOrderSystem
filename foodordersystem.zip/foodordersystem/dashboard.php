<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/admin.css">
    <link rel="stylesheet" href="styles/dashboard.css">
    <title>Dashboard</title>
</head>
<body>
    <div class="admin-panel">
        <div class="sidebar">
            <h1>Admin Panel</h1>
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="user.php">Users</a></li>
                <li><a href="product.php">Products</a></li>
                <li><a href="admin_order.php">Orders</a></li>
                <li><a href="setting.php">Settings</a></li>
            </ul>
        </div>
        <div class="content">
            <h2>Dashboard</h2>
            
            <!-- Quick Stats -->
            <div class="quick-stats">
                <div class="stat-box">
                    <h3>Total Users</h3>
                    <p>50</p>
                </div>
                <div class="stat-box">
                    <h3>Total Products</h3>
                    <p>100</p>
                </div>
                <div class="stat-box">
                    <h3>Total Orders</h3>
                    <p>30</p>
                </div>
            </div>
            
            <!-- Recent Activity -->
            <h3>Recent Activity</h3>
            <ul>
                <li>User John Doe registered.</li>
                <li>New product added: Product A.</li>
                <li>Order #123 placed by User Jane Smith.</li>
                <!-- Add more activity items as needed -->
            </ul>
        </div>
    </div>
</body>
</html>
