<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/admin.css">
    <link rel="stylesheet" href="styles/products.css">
    <title>Product Management</title>
</head>
<body>
    <div class="admin-panel">
        <div class="sidebar">
            <h1>Admin Panel</h1>
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="user.php">Users</a></li>
                <li><a href="product.php">Products</a></li>
                <li><a href="admin_order.php">Orders</a></li>
                <li><a href="setting.php">Settings</a></li>
            </ul>
        </div>
        <div class="content">
            <h2>Product Management</h2>
            
            <!-- Product List -->
            <h3>Product List</h3>
            <table>
                <thead>
                    <tr>
                        <th>Product ID</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Category</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>Product A</td>
                        <td>$50</td>
                        <td>Category 1</td>
                        <td>
                            <a href="#">Edit</a> |
                            <a href="#">Delete</a>
                        </td>
                    </tr>
                    <!-- Add more product rows as needed -->
                </tbody>
            </table>
            
            <!-- Add/Edit Product Form -->
            <h3>Add/Edit Product</h3>
            <form>
                <label for="product-name">Name:</label>
                <input type="text" id="product-name" name="product-name" required>
                
                <label for="product-price">Price:</label>
                <input type="text" id="product-price" name="product-price" required>
                
                <label for="product-category">Category:</label>
                <select id="product-category" name="product-category">
                    <option value="Category 1">Category 1</option>
                    <option value="Category 2">Category 2</option>
                </select>
                
                <input type="submit" value="Save Product">
            </form>
        </div>
    </div>
</body>
</html>
