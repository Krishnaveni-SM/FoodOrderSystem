<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/admin.css">
    <link rel="stylesheet" href="styles/admin_order.css">
    <title>Order Management</title>
</head>
<body>
    <div class="admin-panel">
        <div class="sidebar">
            <h1>Admin Panel</h1>
            <ul>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="user.php">Users</a></li>
                <li><a href="product.php">Products</a></li>
                <li><a href="admin_order.php">Orders</a></li>
                <li><a href="setting.php">Settings</a></li>
            </ul>
        </div>
        <div class="content">
            <h2>Order Management</h2>
            
            <!-- Order List -->
            <h3>Order List</h3>
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Customer Name</th>
                        <th>Total Amount</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>John Doe</td>
                        <td>$150.00</td>
                        <td>Processing</td>
                        <td>
                            <a href="#">View Details</a>
                        </td>
                    </tr>
                    <!-- Add more order rows as needed -->
                </tbody>
            </table>
            
            <!-- Order Details -->
            <div class="order-details">
                <h3>Order Details</h3>
                <p><strong>Order ID:</strong> 1</p>
                <p><strong>Customer Name:</strong> John Doe</p>
                <p><strong>Total Amount:</strong> $150.00</p>
                <p><strong>Status:</strong> Processing</p>
                <!-- Add more order details as needed -->
            </div>
        </div>
    </div>
</body>
</html>
