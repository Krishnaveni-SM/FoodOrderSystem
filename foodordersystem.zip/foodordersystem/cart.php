<html>

  <head>
    <title> Cart </title>
  </head>

  <link rel="stylesheet" type = "text/css" href ="styles/cart.css">
  <link rel="stylesheet" type = "text/css" href ="styles/index.css">

<body>
  <header class="header">
  <style>
    .logo img {
    width: 150px; /* Adjust the width as needed */
    height: auto; /* Maintain the aspect ratio */
    display: inline-block; /* Make the logo inline with the text */
    margin-right: 10px; /* Add spacing between logo and text */
    }
    </style>
    <div class="logo">
        <img src="logo.jpg" alt="Logo">
    </div>
    <nav class="nav">
        <ul>
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="aboutus.php">About</a></li>
            <li><a href="contactus.php">Contact Us</a></li>
            <li><a href="order.php">Orders</a></li>
            <li><a href="menucart.php">MenuCart</a></li>
            <li><a href="cart.php">Cart</a></li>
        </ul>
    </nav>
</header>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "parkingfoodordersystem";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to retrieve data from the cart table
$query = "SELECT * FROM addcart";
$result = $conn->query($query);

$total = 0; 

if ($result->num_rows > 0) {
    echo "<h2>Cart Table Data</h2>";
    echo "<table>";
    echo "<tr>
              <th>Product</th>
              <th>Quantity</th>
              <th>Price</th>
              <th>Total Amount</th>
              <th> Action </th>
          </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["foodname"] . "</td>";
        echo "<td>" . $row["quantity"] . "</td>";
        echo "<td>" . $row["rate"] . "</td>";
        echo "<td>" . ($row["quantity"] * $row["rate"]) . "</td>";
        echo "<td> <button type = 'action'> Remove </button></td>";
        echo "</tr>";
        $total += ($row["quantity"] * $row["rate"]) ;
    }

    echo "<tr>
                  <th colspan='4'>TOTAL</th>
                  <th>$" . $total . "</th>
              </tr>";

              echo "<form method='post'>
              <tr>
                  <td colspan='5'>
                      <!-- Additional form fields for delivery information -->
                      <!-- Hidden input for the total amount -->
                      <input type='hidden' name='total_amount' value='" . $total . "'>
                      <button class='place-order-button' type='submit' name='place_order'>Place Order</button>
                  </td>
              </tr>
          </form>";

        echo "</table>";

} else {
    echo "<p>No data found in the cart table.</p>";
}
?>


<?php
session_start();
$username = $_SESSION['username'];

if(isset($_POST['place_order'])) {
    // Retrieve form data
    $delivery_address = $username;
    $delivery_date = $current_datetime = date("Y-m-d H:i:s"); 
    $total_amount = $_POST['total_amount'];

    // Your database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "parkingfoodordersystem";

    // Create a connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert order details into the placeorder table
    $insert_query = "INSERT INTO placeorder (address, delivery_date, total_amount) VALUES ('$delivery_address', '$delivery_date', '$total_amount')";

    if ($conn->query($insert_query) === TRUE) {
        echo "Order placed successfully.";
    } else {
        echo "Error placing order: " . $conn->error;
    }

    // Close the connection
    $conn->close();
}
?>


  <div class="container">
      <div class="jumbotron">
        <h1>Your Shopping Cart</h1>
        <p>Oops! We can't smell any food here. Go back and <a href="foodlist.php">order now.</a></p>
      </div>
    </div>
    <footer class="footer">
        <div class="footer-content">
            <div class="footer-logo">Toastada</div>
            <div class="footer-social">
                <a href="#"><img src="img/facebook.jpg" alt="Facebook"></a>
                <a href="#"><img src="img/twitter.jpg" alt="Twitter"></a>
                <a href="#"><img src="img/insta.jpg" alt="Instagram"></a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2023 Toastada. All rights reserved.</p>
        </div>
    </footer>

</body>
</html>
