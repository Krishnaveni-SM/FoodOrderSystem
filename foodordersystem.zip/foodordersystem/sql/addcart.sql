CREATE TABLE addcart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255),
    foodname VARCHAR(255),
    quantity INT,
    rate DECIMAL(10, 2)
);